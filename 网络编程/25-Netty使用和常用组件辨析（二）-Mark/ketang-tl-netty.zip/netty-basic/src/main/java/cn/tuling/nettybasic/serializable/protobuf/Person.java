package cn.tuling.nettybasic.serializable.protobuf;

/**
 * @author Mark老师
 * 类说明：实体类
 */
public class Person {
    String name;
    int id;
    String email;
}
