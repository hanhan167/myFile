package com.zhouyu.springboot;

public interface WebServer {

    public void start();
}
