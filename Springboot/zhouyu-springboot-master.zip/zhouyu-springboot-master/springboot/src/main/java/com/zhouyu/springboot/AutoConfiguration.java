package com.zhouyu.springboot;

public interface AutoConfiguration {
}
