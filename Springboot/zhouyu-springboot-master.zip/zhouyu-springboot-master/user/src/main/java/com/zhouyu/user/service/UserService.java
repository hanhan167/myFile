package com.zhouyu.user.service;

import org.springframework.stereotype.Component;

@Component
public class UserService {

    public String test(){
        return "zhouyu";
    }
}
