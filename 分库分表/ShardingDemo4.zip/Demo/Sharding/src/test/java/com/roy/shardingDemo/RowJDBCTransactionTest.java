package com.roy.shardingDemo;

import com.roy.shardingDemo.transaction.XATransactionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author ：楼兰
 * @date ：Created in 2021/4/1
 * @description: 纯JDBC方式实现ShardingSphere分布式事务
 **/


@SpringBootTest
@RunWith(SpringRunner.class)
public class RowJDBCTransactionTest {

    @Resource
    XATransactionService xaTransactionService;
    //测试XA事务管理器
    @Test
    public void xaTransactionTest() throws IOException, SQLException {
//        XATransactionService service = new XATransactionService("/sharding-databases-tables.yaml");
        xaTransactionService.init();

        xaTransactionService.insert();
        xaTransactionService.insertFailed();
        xaTransactionService.cleanup();
    }

    @Test
    public void seataTransactionTest() throws IOException, SQLException {
        SeataTransactionService service = new SeataTransactionService("/META-INF/sharding-databases-tables.yaml");
        service.init();

        service.insert();
        service.insertFailed();
        service.cleanup();
    }
}
