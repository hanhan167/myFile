package com.roy.rabbitmq.direct;

/**
 * @author roy
 * @date 2022/4/25
 * @desc
 */
public class StreamReceiver {


}
