package com.tuling.jucdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JucDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
